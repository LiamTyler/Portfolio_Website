#include "include/square.h"

Square::Square() : Shape(4, 0, 5, .2, 0) {
    x_ = 400;
    y_ = 400;
    w_ = 200;
    h_ = 200;

    sl_ = sr_ = st_ = sb_ = false;
    UpdateVertexPos();
    SetTextureCoords();
}

Square::Square(float x, float y, int tu) : Square(x, y, 200, 200, 9, 0, tu) {}

Square::Square(float x, float y, float w, float h, float edge, float angle, int tu)
    : Shape(4, angle, edge, .2, tu) {
        x_ = x;
        y_ = y;
        w_ = w;
        h_ = h;

        translating_ = rotating_ = animating_ = false;
        sl_ = sr_ = st_ = sb_ = false;
        UpdateVertexPos();
        SetTextureCoords();
    }


void Square::EndMovement() {
    Shape::EndMovement();
    sl_ = sr_ = sb_ = st_ = false;
}

void Square::UpdateVertexPos() {
    vertices_[0] = x_ + w_;  // top right x
    vertices_[1] = y_;       // top right y

    vertices_[2] = x_ + w_;  // bottom right x
    vertices_[3] = y_ + h_;  // bottom right y

    vertices_[4] = x_;       // top left x
    vertices_[5] = y_;       // top left y

    vertices_[6] = x_;       // bottom left x
    vertices_[7] = y_ + h_;  // bottom left y
}

void Square::UpdateVertices(float screen_width, float screen_height) {
    float aspect = screen_width / (float) screen_height;
    UpdateVertexPos();
    float cx = x_ + w_ / 2;
    cx = 2*cx / screen_width - 1;
    float cy = y_ + h_ / 2;
    cy = 1- 2*cy / screen_height;

    // convert to [-1, 1] range
    for (int i = 0; i < 8; i += 2) {
        vertices_[i] *= screen_width / 800.0;
        vertices_[i+1] *= screen_height / 800.0;

        vertices_[i] = 2*vertices_[i]/screen_width - 1;
        vertices_[i+1] = 1- 2*vertices_[i+1]/screen_height;
    }
    // translate to 0,0
    for (int i = 0; i < 8; i += 2) {
        vertices_[i] -= cx ;
        vertices_[i+1] -= cy; 
        /*
        if (aspect < 1) {
            vertices_[i+1] *= aspect;
        } else {
            vertices_[i] /= aspect;
        }
        */
    }
    // rotate
    for (int i = 0; i < 8; i += 2) {
        float x = vertices_[i];
        float y = vertices_[i+1];
        vertices_[i] = x*std::cos(angle_) - y*std::sin(angle_);
        vertices_[i+1] = x*std::sin(angle_) + y*std::cos(angle_);
    }
    // translate back
    for (int i = 0; i < 8; i += 2) {
        vertices_[i] += cx ;
        vertices_[i+1] += cy; 
    }
}

void Square::Update(float screen_width, float screen_height) {
    old_time_ = time_;
    time_ = SDL_GetTicks();
    if (animating_) {
        float dt = (time_ - old_time_) / 1000.0;
        angle_ += dt * 2 * M_PI * RPS_;
    }
    UpdateVertices(screen_width, screen_height);
}

bool Square::mouseClicked(float m_x, float m_y){   
    //unscale rotation to do detections
    float cx = x_ + w_ / 2;
    float cy = y_ + h_ / 2;
    float umx = m_x - cx;
    float umy = cy - m_y;
    float mx = umx*std::cos(-angle_) - umy*std::sin(-angle_) + cx;
    float my = cy - (umx*std::sin(-angle_) + umy*std::cos(-angle_));

    if (!(x_ <= mx && mx <= x_ + w_ &&
                y_ <= my && my <= y_ + h_)) {
        return false;
    }
    animating_ = false;

    // check for left side
    if (mx < x_ + edge_) {
        // check for top corner
        if (my < y_ + edge_) {
            // std::cout << "Top left corner!" << std::endl;
        } else if (my > y_ + h_ - edge_) { // check for bottom corner
            // std::cout << "Bottom left corner!" << std::endl;
        } else {
            // std::cout << "Left Edge!" << std::endl;
            sl_ = true;
        }
        if (!sl_) { // if corner grabbed
            old_angle_ = std::atan2(my - cy, mx - cx);
            rotating_ = true;
        }
        return true;
    } 
    // check for right side
    if (mx > x_ + w_ - edge_) {
        // check for top corner
        if (my < y_ + edge_) {
            // std::cout << "Top right corner!" << std::endl;
        } else if (my > y_ + h_ - edge_) { // check for bottom corner
            // std::cout << "Bottom right corner!" << std::endl;
        } else {
            sr_ = true;
        }
        if (!sr_) { // if corner grabbed
            old_angle_ = std::atan2(my - cy, mx - cx);
            rotating_ = true;
        }
        return true;
    } 
    // check for top edge
    if (my < y_ + edge_) {
        // std::cout << "Top edge!" << std::endl;
        st_ = true;
        return true;
    } 
    // check for bottom edge
    if (my > y_ + h_ - edge_) {
        // std::cout << "Bottom edge!" << std::endl;
        sb_ = true;
        return true;
    } 

    //Let's assume the user clicked in the middle of the square
    translating_ = true;
    rotating_ = false;
    scaling_ = false;
    return true;
}

bool Square::mouseDragged(float m_x, float m_y){
    float cx = x_ + w_ / 2;
    float cy = y_ + h_ / 2;
    float umx = m_x - cx;
    float umy = cy - m_y;
    float mx = umx*std::cos(-angle_) - umy*std::sin(-angle_) + cx;
    float my = cy - (umx*std::sin(-angle_) + umy*std::cos(-angle_));

    if (translating_){
        x_ = m_x - w_ / 2;
        y_ = m_y - h_ / 2;
        color_[0] = 0;
        color_[1] = 1;
        color_[2] = 0;
    }
    if (rotating_) {
        float a = std::atan2(my - cy, mx - cx);
        float da = a - old_angle_;
        angle_ -= da;
        color_[0] = 1;
        color_[1] = 0;
        color_[2] = 0;
    }

    if (sl_ || st_ || sr_ || sb_) {
        color_[0] = 1;
        color_[1] = 0;
        color_[2] = 1;
        float d = 0;
        if (sl_) {
            d = x_ - mx;
        } else if (st_) {
            d = y_ - my;
        } else if (sr_) {
            d = mx - (x_ + w_);
        } else if (sb_) {
            d = my - (y_ + h_);
        } 

        if (w_ + 2*d > 0 && h_ + 2*d > 0) {
            x_ -= d;
            w_ += 2*d;
            y_ -= d;
            h_ += 2*d;
        }
    }
    return true;
}

void Square::SetTextureCoords() {
    texCoords_[0] = 1;  // top right x
    texCoords_[1] = 1; // top right y

    texCoords_[2] = 1; // bottom right x
    texCoords_[3] = 0;  // bottom right y

    texCoords_[4] = 0; // top left x
    texCoords_[5] = 1; // top left y

    texCoords_[6] = 0; // bottom left x
    texCoords_[7] = 0; // bottom left y
}

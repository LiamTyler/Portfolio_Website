#ifndef TRIANGLE_H_
#define TRIANGLE_H_

#include <iostream>
#include "include/utils.h"
#include "include/shape.h"

class Triangle : public Shape {
    public:
        Triangle(int tu);
        void SetTextureCoords();
        void Move(float dx, float dy);
        void UpdateVertexPos();
        void UpdateVertices(float screen_width, float screen_height);
        void Update(float screen_width, float screen_height);
        Point GetCentroid();
        bool mouseClicked(float mx, float my);
        bool mouseDragged(float mx, float my);

    protected:
        Point p0;
        Point p1;
        Point p2;
        float old_scale_;
};

#endif  // TRIANGLE_H_

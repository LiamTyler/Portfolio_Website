#ifndef UTILS_H_
#define UTILS_H_

#include "include/glad.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#include <cmath>

typedef struct Point {
    float x;
    float y;
    Point() : x(0), y(0) {}
    Point(float xx, float yy) {
        x = xx;
        y = yy;
    }
} Point;

inline float DistanceBetween(Point p, Point q) {
    return std::sqrt((q.y-p.y)*(q.y-p.y) + (q.x-p.x)*(q.x-p.x));
}

inline float ClosestDistance(Point p, Point q, Point m) {
    float num = std::abs((q.y - p.y)*m.x - (q.x - p.x)*m.y + q.x*p.y-q.y*p.x);
    float denom = DistanceBetween(p, q);
    return num / denom;
}

typedef GLuint Texture;

inline Texture loadTexture(std::string bmp) {
    SDL_Surface *s = SDL_LoadBMP(bmp.c_str());
    if (!s) {
        std::cout << "Failed to load bmp: " << SDL_GetError() << std::endl;
        exit(EXIT_FAILURE);
    }
    SDL_LockSurface(s);
    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, s->w, s->h, 0, GL_BGR, GL_UNSIGNED_BYTE, s->pixels);
    glGenerateMipmap(GL_TEXTURE_2D);
    SDL_FreeSurface(s);
    return texture;
}

#endif  // UTILS_H_

#include <iostream>
#include <cmath>

using namespace std;

int main(int argc, char* argv[]) {
    cout << asin(1 / 0) << endl;

    return 0;
}
